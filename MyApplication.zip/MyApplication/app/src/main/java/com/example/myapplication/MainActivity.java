package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView textViewHello;
    private EditText editTextInsert;
    private ImageView imageViewSlika;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewHello= findViewById(R.id.textViewHelLo);

        editTextInsert = findViewById(R.id.editTextInsert);

        imageViewSlika = findViewById(R.id.imageViewSlika);
    }
    public void clickButtonChanges(View view){
        String text="";
        text = editTextInsert.getText().toString();
        textViewHello.setText(text);
    }
    public void clickButtonPrvi(View view){
        imageViewSlika.setImageResource(R.drawable.macka);
        Toast.makeText(getApplicationContext(), "Macka", Toast.LENGTH_SHORT);
    }

    public void clickButtonDrugi(View view){
        imageViewSlika.setImageResource(R.drawable.traktor);
        Toast.makeText(getApplicationContext(), "Traktor", Toast.LENGTH_SHORT);
    }
}